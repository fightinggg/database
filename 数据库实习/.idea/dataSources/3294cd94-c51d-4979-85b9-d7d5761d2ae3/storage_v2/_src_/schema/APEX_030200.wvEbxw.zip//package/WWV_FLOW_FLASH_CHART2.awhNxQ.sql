create package wwv_flow_flash_chart2
as

procedure chart(p_report_id in number default null);

end wwv_flow_flash_chart2;
/

