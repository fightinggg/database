create package wwv_flow_calendar_ajax as

procedure widget;

end wwv_flow_calendar_ajax;
/

