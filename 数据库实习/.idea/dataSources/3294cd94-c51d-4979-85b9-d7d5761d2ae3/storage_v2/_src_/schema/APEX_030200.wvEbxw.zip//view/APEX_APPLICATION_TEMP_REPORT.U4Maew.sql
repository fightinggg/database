create view APEX_APPLICATION_TEMP_REPORT as
select
    w.short_name                     workspace,
    f.ID                             application_id,
    f.NAME                           application_name,
    --
    t.ROW_TEMPLATE_NAME              template_name,
    decode(t.ROW_TEMPLATE_TYPE,
      'GENERIC_COLUMNS','Generic Columns (column template)',
      'NAMED_COLUMNS','Named Column (row template)',
      t.ROW_TEMPLATE_TYPE)           template_type,
      --
    t.before_column_heading          ,
    t.COLUMN_HEADING_TEMPLATE        ,
    t.after_column_heading           ,
    t.ROW_TEMPLATE1                  col_TEMPLATE1                ,
    t.ROW_TEMPLATE_CONDITION1        col_TEMPLATE_CONDITION1      ,
    t.ROW_TEMPLATE_DISPLAY_COND1     col_TEMPLATE_DISPLAY_COND1   ,
    t.ROW_TEMPLATE2                  col_TEMPLATE2                ,
    t.ROW_TEMPLATE_CONDITION2        col_TEMPLATE_CONDITION2      ,
    t.ROW_TEMPLATE_DISPLAY_COND2     col_TEMPLATE_DISPLAY_COND2   ,
    t.ROW_TEMPLATE3                  col_TEMPLATE3                ,
    t.ROW_TEMPLATE_CONDITION3        col_TEMPLATE_CONDITION3      ,
    t.ROW_TEMPLATE_DISPLAY_COND3     col_TEMPLATE_DISPLAY_COND3   ,
    t.ROW_TEMPLATE4                  col_TEMPLATE4                ,
    t.ROW_TEMPLATE_CONDITION4        col_TEMPLATE_CONDITION4      ,
    t.ROW_TEMPLATE_DISPLAY_COND4     col_TEMPLATE_DISPLAY_COND4   ,
    t.ROW_TEMPLATE_BEFORE_ROWS       col_TEMPLATE_BEFORE_ROWS     ,
    t.ROW_TEMPLATE_AFTER_ROWS        col_TEMPLATE_AFTER_ROWS      ,
    t.ROW_TEMPLATE_BEFORE_FIRST      col_TEMPLATE_BEFORE_FIRST    ,
    t.ROW_TEMPLATE_AFTER_LAST        col_TEMPLATE_AFTER_LAST      ,
    --t.ROW_TEMPLATE_TABLE_ATTRIBUTES  col_TEMPLATE_TABLE_ATTRIBUTES,
    t.PAGINATION_TEMPLATE            ,
    t.NEXT_PAGE_TEMPLATE             ,
    t.PREVIOUS_PAGE_TEMPLATE         ,
    t.NEXT_SET_TEMPLATE              ,
    t.PREVIOUS_SET_TEMPLATE          ,
    t.ROW_STYLE_MOUSE_OVER           ,
    --t.ROW_STYLE_MOUSE_OUT            ,
    t.ROW_STYLE_CHECKED              ,
    --t.ROW_STYLE_UNCHECKED            ,
    --
    decode(t.REFERENCE_ID,
    null,'No','Yes')                 is_subscribed,
    (select flow_id||'. '||name
     from WWV_FLOW_ROW_TEMPLATES
     where id = t.REFERENCE_ID)      subscribed_from,
    --
    t.LAST_UPDATED_BY                ,
    t.LAST_UPDATED_ON                ,
    t.THEME_ID                       theme_number,
    --
    decode(t.THEME_CLASS_ID,
      '1','Borderless',
      '2','Horizontal Border',
      '3','One Column Unordered List',
      '4','Standard',
      '5','Standard, Alternating Row Colors',
      '6','Value Attribute Pairs',
      '7','Custom 1',
      '8','Custom 2',
      '9','Custom 3',
      '10','Custom 4',
      '11','Custom 5',
      '12','Custom 6',
      '13','Custom 7',
      '14','Custom 8',
      t.THEME_CLASS_ID)              theme_class,
    decode(t.TRANSLATE_THIS_TEMPLATE,
       'Y','Yes','N','No','Yes')     translate_this_template,
    t.ROW_TEMPLATE_COMMENT           component_comment,
    --
    t.ROW_TEMPLATE_NAME
    ||' t='||t.THEME_ID
    ||' c='||t.THEME_CLASS_ID
    ||' t='||t.ROW_TEMPLATE_TYPE
    ||' 1='||dbms_lob.substr(t.ROW_TEMPLATE1,1,40)||dbms_lob.getlength(t.ROW_TEMPLATE1)
    ||' c='||substr(t.ROW_TEMPLATE_CONDITION1   ,1,20)||length(t.ROW_TEMPLATE_CONDITION1)
    ||' c='||substr(t.ROW_TEMPLATE_DISPLAY_COND1,1,20)||length(t.ROW_TEMPLATE_DISPLAY_COND1)
    ||' 2='||dbms_lob.substr(t.ROW_TEMPLATE2,1,40)||dbms_lob.getlength(t.ROW_TEMPLATE2)
    ||' c='||substr(t.ROW_TEMPLATE_CONDITION2   ,1,20)||length(t.ROW_TEMPLATE_CONDITION2)
    ||' c='||substr(t.ROW_TEMPLATE_DISPLAY_COND2,1,20)||length(t.ROW_TEMPLATE_DISPLAY_COND2)
    ||' 3='||dbms_lob.substr(t.ROW_TEMPLATE3,1,40)||dbms_lob.getlength(t.ROW_TEMPLATE3)
    ||' c='||substr(t.ROW_TEMPLATE_CONDITION3   ,1,20)||length(t.ROW_TEMPLATE_CONDITION3)
    ||' c='||substr(t.ROW_TEMPLATE_DISPLAY_COND3,1,20)||length(t.ROW_TEMPLATE_DISPLAY_COND3)
    ||' 4='||dbms_lob.substr(t.ROW_TEMPLATE4,1,40)||dbms_lob.getlength(t.ROW_TEMPLATE4)
    ||decode(t.REFERENCE_ID,null,'N','Y')
    component_signature,
    t.id template_id
from WWV_FLOW_ROW_TEMPLATES t,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_030200')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      f.id = t.flow_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0 and
      (user in ('SYS','SYSTEM', 'APEX_030200') or w.PROVISIONING_COMPANY_ID != 10)
/

comment on table APEX_APPLICATION_TEMP_REPORT is 'Identifies the HTML template markup used to render a Report Headings and Rows'
/

comment on column APEX_APPLICATION_TEMP_REPORT.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPLICATION_TEMP_REPORT.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_APPLICATION_TEMP_REPORT.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_APPLICATION_TEMP_REPORT.TEMPLATE_NAME is 'Identifies a name for this template'
/

comment on column APEX_APPLICATION_TEMP_REPORT.TEMPLATE_TYPE is 'Displays the type of the template - either Named columns or Generic Columns'
/

comment on column APEX_APPLICATION_TEMP_REPORT.BEFORE_COLUMN_HEADING is 'Emit this before the column header cell.'
/

comment on column APEX_APPLICATION_TEMP_REPORT.COLUMN_HEADING_TEMPLATE is 'This attribute is only applicable to generic column templates. Use this template to colorize each column header cell.'
/

comment on column APEX_APPLICATION_TEMP_REPORT.AFTER_COLUMN_HEADING is 'Emit this after the column header cell.'
/

comment on column APEX_APPLICATION_TEMP_REPORT.COL_TEMPLATE1 is 'Defines the column template, use #COLUMN_VALUE#, #ALIGNMENT#, #COLNUM#, #COLUMN_HEADER#, #COLCOUNT#, #ROW_NUM# substitutions'
/

comment on column APEX_APPLICATION_TEMP_REPORT.COL_TEMPLATE_CONDITION1 is 'Optionally select a condition type that must be met in order to apply this column template'
/

comment on column APEX_APPLICATION_TEMP_REPORT.COL_TEMPLATE_DISPLAY_COND1 is 'A condition that must be met in order to apply this column template'
/

comment on column APEX_APPLICATION_TEMP_REPORT.COL_TEMPLATE2 is 'Defines the column template, use #COLUMN_VALUE#, #ALIGNMENT#, #COLNUM#, #COLUMN_HEADER#, #COLCOUNT#, #ROW_NUM# substitutions'
/

comment on column APEX_APPLICATION_TEMP_REPORT.COL_TEMPLATE_CONDITION2 is 'Optionally select a condition type that must be met in order to apply this column template'
/

comment on column APEX_APPLICATION_TEMP_REPORT.COL_TEMPLATE_DISPLAY_COND2 is 'A condition that must be met in order to apply this column template'
/

comment on column APEX_APPLICATION_TEMP_REPORT.COL_TEMPLATE3 is 'Defines the column template, use #COLUMN_VALUE#, #ALIGNMENT#, #COLNUM#, #COLUMN_HEADER#, #COLCOUNT#, #ROW_NUM# substitutions'
/

comment on column APEX_APPLICATION_TEMP_REPORT.COL_TEMPLATE_CONDITION3 is 'Optionally select a condition type that must be met in order to apply this column template'
/

comment on column APEX_APPLICATION_TEMP_REPORT.COL_TEMPLATE_DISPLAY_COND3 is 'A condition that must be met in order to apply this column template'
/

comment on column APEX_APPLICATION_TEMP_REPORT.COL_TEMPLATE4 is 'Defines the column template, use #COLUMN_VALUE#, #ALIGNMENT#, #COLNUM#, #COLUMN_HEADER#, #COLCOUNT#, #ROW_NUM# substitutions'
/

comment on column APEX_APPLICATION_TEMP_REPORT.COL_TEMPLATE_CONDITION4 is 'Optionally select a condition type that must be met in order to apply this column template'
/

comment on column APEX_APPLICATION_TEMP_REPORT.COL_TEMPLATE_DISPLAY_COND4 is 'A condition that must be met in order to apply this column template'
/

comment on column APEX_APPLICATION_TEMP_REPORT.COL_TEMPLATE_BEFORE_ROWS is 'HTML which will be displayed one time at the beginning of a report template'
/

comment on column APEX_APPLICATION_TEMP_REPORT.COL_TEMPLATE_AFTER_ROWS is 'HTML which will be displayed one time at the beginning of a report template'
/

comment on column APEX_APPLICATION_TEMP_REPORT.COL_TEMPLATE_BEFORE_FIRST is 'Display this text before displaying all columns for the report. Use this attribute to open a new HTML row'
/

comment on column APEX_APPLICATION_TEMP_REPORT.COL_TEMPLATE_AFTER_LAST is 'Display this HTML after all columns for the report display. Typically used to close an HTML table row'
/

comment on column APEX_APPLICATION_TEMP_REPORT.PAGINATION_TEMPLATE is 'This attribute will be applied to the entire pagination subtemplate.'
/

comment on column APEX_APPLICATION_TEMP_REPORT.NEXT_PAGE_TEMPLATE is 'HTML that will modify how the "Next Page" portion of the pagination subtemplate will appear'
/

comment on column APEX_APPLICATION_TEMP_REPORT.PREVIOUS_PAGE_TEMPLATE is 'HTML that will modify how the "Previous Page" portion of the pagination subtemplate will appear'
/

comment on column APEX_APPLICATION_TEMP_REPORT.NEXT_SET_TEMPLATE is 'HTML that will modify how the "Next Set" portion of the pagination subtemplate will appear'
/

comment on column APEX_APPLICATION_TEMP_REPORT.PREVIOUS_SET_TEMPLATE is 'HTML that will modify how the "Previous Set" portion of the pagination subtemplate will appear'
/

comment on column APEX_APPLICATION_TEMP_REPORT.ROW_STYLE_MOUSE_OVER is 'This attribute controls the background color of a report row when the user moves the mouse over the row'
/

comment on column APEX_APPLICATION_TEMP_REPORT.ROW_STYLE_CHECKED is 'This attribute controls the background color of a report row when the row selector is checked'
/

comment on column APEX_APPLICATION_TEMP_REPORT.IS_SUBSCRIBED is 'Identifies if this Report Template is subscribed from another Report Template'
/

comment on column APEX_APPLICATION_TEMP_REPORT.SUBSCRIBED_FROM is 'Identifies the master component from which this component is subscribed'
/

comment on column APEX_APPLICATION_TEMP_REPORT.LAST_UPDATED_BY is 'Apex developer who made last update'
/

comment on column APEX_APPLICATION_TEMP_REPORT.LAST_UPDATED_ON is 'Date of last update'
/

comment on column APEX_APPLICATION_TEMP_REPORT.THEME_NUMBER is 'Identifies the numeric identifier of this theme to which this template is associated'
/

comment on column APEX_APPLICATION_TEMP_REPORT.THEME_CLASS is 'Identifies a specific usage for this template'
/

comment on column APEX_APPLICATION_TEMP_REPORT.TRANSLATE_THIS_TEMPLATE is 'Identifies if this template should be translated'
/

comment on column APEX_APPLICATION_TEMP_REPORT.COMPONENT_COMMENT is 'Developer Comment'
/

comment on column APEX_APPLICATION_TEMP_REPORT.COMPONENT_SIGNATURE is 'Identifies attributes defined at a given component level to facilitate application comparisons'
/

comment on column APEX_APPLICATION_TEMP_REPORT.TEMPLATE_ID is 'Unique ID of report template'
/

