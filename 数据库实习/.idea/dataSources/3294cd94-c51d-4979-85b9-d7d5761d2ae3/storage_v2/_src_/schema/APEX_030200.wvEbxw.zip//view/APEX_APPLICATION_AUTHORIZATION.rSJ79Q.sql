create view APEX_APPLICATION_AUTHORIZATION as
select
    w.short_name                     workspace,
    f.ID                             application_id,
    f.NAME                           application_name,
    --
    a.NAME                           authorization_scheme_name,
    a.SCHEME_TYPE                    scheme_type,
    a.SCHEME                         scheme,
    a.SCHEME_TEXT                    scheme_text,
    a.ERROR_MESSAGE                  error_message,
    --
    decode(a.CACHING,
      'BY_USER_BY_PAGE_VIEW','Once per page view',
      'BY_USER_BY_SESSION','Once per session',
      a.CACHING)                     caching,
    decode(a.REFERENCE_ID,null,'No','Yes') is_subscribed,
    a.LAST_UPDATED_BY                last_updated_by,
    a.LAST_UPDATED_ON                last_updated_on,
    a.COMMENTS                       component_comment,
    --
    a.id                             authorization_scheme_id,
    a.REFERENCE_ID                   referenced_scheme_id,
    --
    substr(a.NAME,1,30)||length(a.NAME         )
    ||' t='||substr(a.SCHEME_TYPE  ,1,30)||length(a.SCHEME_TYPE  )
    ||' s='||substr(a.SCHEME       ,1,30)||length(a.SCHEME       )
    ||' t='||substr(a.SCHEME_TEXT  ,1,30)||length(a.SCHEME_TEXT  )
    ||' e='||substr(a.ERROR_MESSAGE,1,30)||length(a.ERROR_MESSAGE)
    ||' s='||decode(a.CACHING,'BY_USER_BY_PAGE_VIEW','Once per page view','BY_USER_BY_SESSION','Once per session',substr(a.CACHING,1,20))
    ||' r='||decode(a.REFERENCE_ID,null,'No','Yes')
    component_signature
from WWV_FLOW_SECURITY_SCHEMES a,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_030200')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      f.id = a.flow_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0 and
      (user in ('SYS','SYSTEM', 'APEX_030200') or w.PROVISIONING_COMPANY_ID != 10)
/

comment on table APEX_APPLICATION_AUTHORIZATION is 'Identifies Authorization Schemes which can be applied at the application, page or component level'
/

comment on column APEX_APPLICATION_AUTHORIZATION.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPLICATION_AUTHORIZATION.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_APPLICATION_AUTHORIZATION.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_APPLICATION_AUTHORIZATION.AUTHORIZATION_SCHEME_NAME is 'Name of the Authorization Scheme'
/

comment on column APEX_APPLICATION_AUTHORIZATION.SCHEME_TYPE is 'Type of Authorization Scheme which defines how the Authorization Scheme Source will be interpreted'
/

comment on column APEX_APPLICATION_AUTHORIZATION.SCHEME is 'Identifies the Authorization Scheme.  Session state my be referenced using bind variables for Schemes of type SQL or PL/SQL.'
/

comment on column APEX_APPLICATION_AUTHORIZATION.SCHEME_TEXT is 'Further Identifies an Authorization Scheme, used only for specific Authorization Scheme Types'
/

comment on column APEX_APPLICATION_AUTHORIZATION.ERROR_MESSAGE is 'Identifies the Error Message end users will see when this Authentication Scheme fails'
/

comment on column APEX_APPLICATION_AUTHORIZATION.CACHING is 'Identifies the level of Caching used for this Authentication Scheme; typically by Session or Page View.'
/

comment on column APEX_APPLICATION_AUTHORIZATION.IS_SUBSCRIBED is 'Identifies if this Authorization Scheme is subscribed from another Authorization Scheme.'
/

comment on column APEX_APPLICATION_AUTHORIZATION.LAST_UPDATED_BY is 'Apex developer who made last update'
/

comment on column APEX_APPLICATION_AUTHORIZATION.LAST_UPDATED_ON is 'Date of last update'
/

comment on column APEX_APPLICATION_AUTHORIZATION.COMPONENT_COMMENT is 'Developer comment'
/

comment on column APEX_APPLICATION_AUTHORIZATION.AUTHORIZATION_SCHEME_ID is 'Primary Key of this Authorization Scheme'
/

comment on column APEX_APPLICATION_AUTHORIZATION.REFERENCED_SCHEME_ID is 'Foreign Key of referenced Authorization Scheme'
/

comment on column APEX_APPLICATION_AUTHORIZATION.COMPONENT_SIGNATURE is 'Identifies attributes defined at a given component level to facilitate application comparisons'
/

