create view WWV_FLOW_PLSQL_JOBS as
select id, job, flow_id, owner, enduser, created, modified,
         status, system_status, system_modified, security_group_id
    from wwv_flow_jobs
   where security_group_id = (select nv('FLOW_SECURITY_GROUP_ID') sgid from dual)
/

