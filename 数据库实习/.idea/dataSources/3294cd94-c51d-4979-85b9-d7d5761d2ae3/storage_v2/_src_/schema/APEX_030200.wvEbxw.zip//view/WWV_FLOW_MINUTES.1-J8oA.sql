create view WWV_FLOW_MINUTES (MINUTE_VALUE) as
select i-1 from wwv_flow_dual100 where i < 61
/

