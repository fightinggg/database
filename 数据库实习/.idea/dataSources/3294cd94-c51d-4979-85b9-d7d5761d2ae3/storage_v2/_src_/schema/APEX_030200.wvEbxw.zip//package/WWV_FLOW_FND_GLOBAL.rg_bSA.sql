create package WWV_FLOW_FND_GLOBAL
is
    user_id number;
end wwv_flow_fnd_global;
/

