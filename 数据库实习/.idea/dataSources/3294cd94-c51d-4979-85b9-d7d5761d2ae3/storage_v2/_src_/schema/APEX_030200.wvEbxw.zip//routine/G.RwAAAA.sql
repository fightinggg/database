create procedure g wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
7
5c 96
V6dMM+TzTwnkXXn8KaCUT5XyeOkwg7KvLfOpynSmZ/boDnfUFafF8edu7Ljzofr5un2qXPRG
ZPGux4ECEFvwiPW6dnpIsMO0Ok+TLMZs31nSz2XM/VCr28+2xJSVztPdN9PBRTaAXziSprq/
BJ4=
/

