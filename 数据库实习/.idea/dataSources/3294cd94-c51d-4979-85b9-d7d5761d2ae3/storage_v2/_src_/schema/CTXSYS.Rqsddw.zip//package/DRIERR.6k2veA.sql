create package drierr authid definer as

/*-------------------------- AddODCIWarning -------------------------------*/

procedure AddODCIWarning(pretext IN boolean := FALSE);

/*---------------------------- RecordIndexError -------------------------*/
/* records an error to the dr$index_error table */

procedure RecordIndexError(
  p_idxid           in number,
  p_textkey         in varchar2,
  p_stack           in varchar2
);

procedure RecordIndexErrorId(
  p_idxid           in number,
  p_textkey         in varchar2,
  msgid             in binary_integer,
  arg1	            in varchar2	default NULL,
  arg2	            in varchar2	default NULL,
  arg3	            in varchar2	default NULL,
  arg4	            in varchar2	default NULL,
  arg5	            in varchar2	default NULL
);

end drierr;
/

