create type dr$popindex_state_t as object(
  session_state   dr$session_state_t,
  opcode          varchar2(128),
  index_memory    varchar2(256),
  tstamp          varchar2(256),
  direct_path     varchar2(10),
  maxtime         varchar2(10)
);
/

