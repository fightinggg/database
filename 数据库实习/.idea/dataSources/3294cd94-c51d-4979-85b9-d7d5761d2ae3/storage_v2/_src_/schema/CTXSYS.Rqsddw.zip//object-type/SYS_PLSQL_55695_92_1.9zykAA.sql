create type          SYS_PLSQL_55695_92_1 as table of CTXSYS."SYS_PLSQL_55695_74_1";
/

