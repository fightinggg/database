create package CTX_DDL authid current_user as

  OPTLEVEL_FAST                   constant varchar2(4)  := 'FAST';
  OPTLEVEL_FULL                   constant varchar2(4)  := 'FULL';
  OPTLEVEL_TOKEN                  constant varchar2(5)  := 'TOKEN';
  OPTLEVEL_TOKEN_TYPE             constant varchar2(10) := 'TOKEN_TYPE';
  OPTLEVEL_REBUILD                constant varchar2(7)  := 'REBUILD';
  OPTLEVEL_MERGE                  constant varchar2(5)  := 'MERGE';
  MAXTIME_UNLIMITED               constant number := 2147483647;


  LOCK_WAIT         constant number := 0;
  LOCK_NOWAIT       constant number := 1;
  LOCK_NOWAIT_ERROR constant number := 2;

TYPE split_rec is RECORD(
new_sec varchar2(64) default NULL,
idval varchar2(100) default NULL
);
TYPE split_tab is table of split_rec index by binary_integer;

  --
  -- Public procedure prototypes
  --


/*---------------------------- create_preference ----------------------------*/
/*
  NAME
    create_preference
  DESCRIPTION
    A preference is created to customized a tile (framework object).

    A preference references a framework object. It describes how a referenced
    object is to be customized.

    This procedure validates the preference attribute settings and raise
    an exveption if incorrect attribute settings are found.

  ARGUMENTS
    preference_name -  preference name, this is structured as
                       [OWNER.]PREFERENCE_NAME
    object_name     - object name
  NOTES
    a) this procedure clears out the list of attributes created (by
       calling the set_attribute()) prior to calling this procedure.
  EXCEPTIONS

  RETURNS
    none
*/
procedure create_preference(
  preference_name  in varchar2,
  object_name      in varchar2);

/*---------------------------- drop_preference ----------------------------*/
/*
  NAME
    drop_preference
  DESCRIPTION
    delete the preference specified in 'name' from TexTile dictionary.
    This procedure will raise an exception if the preference is referenced
    in any policy.
  ARGUMENTS
    name    - preference name
  NOTES
    NONE
  EXCEPTIONS

*/
procedure drop_preference(preference_name  in varchar2 );

/*---------------------------- set_attribute ----------------------------*/
/*
  NAME
    set_attribute
  DESCRIPTION
    add an item into the  attribute name/value buffer for preference creation.
    The caller calls this  procedure to set value for a named preference
    attribute.
    the create_preference() procedure make used of all values set by this
    procedure when creating the preference. The attribute name/value  buffer
    is cleaned up once the preference is created.

  ARGUMENTS
    name     - preference attribute name
    value    - the attribute value
  NOTES

  EXCEPTIONS

*/
procedure set_attribute(preference_name in varchar2,
                        attribute_name  in varchar2,
                        attribute_value in varchar2);

/*-------------------------- unset_attribute ----------------------------*/

procedure unset_attribute(preference_name in varchar2,
                        attribute_name  in varchar2);


/*-------------------- create_section_group  ---------------------------*/
/*
  NAME
    create_section_group

  DESCRIPTION
    create a new section group.

    * section group name is unique within an owner.
    * Only CTXAPP and CTXADMIN users can create a section group.

  ARGUMENTS
    group_name  - section group name , [user.]section_group_name
    group_type  - section group type ( from ctx_classes )
  NOTES

  EXCEPTIONS

*/
PROCEDURE create_section_group(
  group_name     in    varchar2
, group_type     in    varchar2
);

/*-------------------- drop_section_group  ---------------------------*/
/*
  NAME
    drop_section_group

  DESCRIPTION
    drop a new group.  Only CTXAPP and CTXADMIN can drop a section
    group, moreover, they can only drop their own section group.

  ARGUMENTS
    group_name  -  section group name, [user.]section_group_name

  NOTES

  EXCEPTIONS

*/
PROCEDURE drop_section_group(
  group_name     in    varchar2
);

/*-------------------- add_zone_section  ---------------------------*/
/*
  NAME
    add_zone_section

  DESCRIPTION
    add a new section.

    * tag is unique within a section group

    * section names are not unique within a section group.  this allows
      defining multiple patterns for the same logical section, makeing the
      details transparent to searches.

    * no field and zone section name within a section group should be the same
  ARGUMENTS
    group_name   - section group name, [user.]section_group_name
    section_name - section name
    tag          - the pattern which marks the start of a section

  NOTES

  EXCEPTIONS

*/
PROCEDURE add_zone_section(
  group_name     in    varchar2,
  section_name   in    varchar2,
  tag            in    varchar2
);


/*-------------------- add_field_section  -------------------------*/
/*
  NAME
    add_field_section

  DESCRIPTION
    add a new field section.

    * tag is unique within a section group

    * at most 16 unique field sections with a section group

    * no field and zone section name within a section group should be the same
  ARGUMENTS
    group_name   - section group name, [user.]section_group_name
    section_name - section name
    tag          - the pattern which marks the start of a section

  NOTES

  EXCEPTIONS

*/
PROCEDURE add_field_section(
  group_name     in    varchar2,
  section_name   in    varchar2,
  tag            in    varchar2,
  visible        in    boolean default FALSE
);

/*-------------------- add_special_section  ---------------------------*/
/*
  NAME
    add_special_section

  DESCRIPTION
    add a special section to the group
    special sections are not detected by tags.  Instead, they are
    detected automatically in the document text.

  ARGUMENTS
    group_name   - section group name, [user.]section_group_name
    section_name - the special section to add

  NOTES
    The following are valid special sections:

    for all types:
      SENTENCE
      PARAGRAPH

  EXCEPTIONS

*/
PROCEDURE add_special_section(
  group_name     in    varchar2
, section_name   in    varchar2
);

/*-------------------- add_stop_section  -----------------------------*/
/*
  NAME
    add_stop_section

  DESCRIPTION
    add a stop section to the group
    stop sections can be added only to the auto sectioner.  They denote
    those tags which should not be indexed.

  ARGUMENTS
    group_name   - section group name, [user.]section_group_name
    tag          - the tag to stop

  NOTES

  EXCEPTIONS

*/
PROCEDURE add_stop_section(
  group_name     in    varchar2
, tag            in    varchar2
);

/*-------------------- add_attr_section  -----------------------------*/
/*
  NAME
    add_attr_section

  DESCRIPTION
    add an attribute section to the group
    attr sections can be added only to the xml sectioner.
    They denote attributes whose text should be indexed

  ARGUMENTS
    group_name   - section group name, [user.]section_group_name
    section_name - section name
    tag          - the tag to index -- MUST be in form TAG@ATTR

  NOTES

  EXCEPTIONS

*/
PROCEDURE add_attr_section(
  group_name     in    varchar2
, section_name   in    varchar2
, tag            in    varchar2
);

/*-------------------- add_mdata_section  -------------------------*/
/*
  NAME
    add_mdata_section

  DESCRIPTION
    add a new mdata section.

    * tag is unique within a section group

    * at most 99 unique mdata sections with a section group

    * no section name unique within a section group

  ARGUMENTS
    group_name   - section group name, [user.]section_group_name
    section_name - section name
    tag          - the pattern which marks the start of a section
    allow_remove - TRUE if calling remove_mdata() for this particlar
                   mdata section is allowed. The trade-off here is that
                   query will run a bit faster if this is set to FALSE.

  NOTES

  EXCEPTIONS

*/
PROCEDURE add_mdata_section(
  group_name     in    varchar2,
  section_name   in    varchar2,
  tag            in    varchar2,
  allow_remove   in    boolean default TRUE
);

/*-------------------- add_ndata_section  -------------------------*/
/*
  NAME
    add_ndata_section

  DESCRIPTION
    add a new ndata section.

    * tag is unique within a section group

    * at most 99 unique ndata sections with a section group

    * no section name unique within a section group

  ARGUMENTS
    group_name   - section group name, [user.]section_group_name
    section_name - section name
    tag          - the pattern which marks the start of a section

  NOTES

  EXCEPTIONS

*/
PROCEDURE add_ndata_section(
  group_name     in    varchar2,
  section_name   in    varchar2,
  tag            in    varchar2
);

/*-------------------- add_mvdata_section  -------------------------*/
/*
  NAME
    add_mvdata_section

  DESCRIPTION
    add a new mvdata section.

    * tag is unique within a section group

    * at most 100 unique mvdata sections with a section group

    * no section name unique within a section group

  ARGUMENTS
    group_name   - section group name, [user.]section_group_name
    section_name - section name
    tag          - the pattern which marks the start of a section
    datatype     - datatype of the section

  NOTES

  EXCEPTIONS

*/
PROCEDURE add_mvdata_section(
  group_name     in    varchar2,
  section_name   in    varchar2,
  tag            in    varchar2,
  datatype       in    varchar2  default NULL
);

/*-------------------- add_sdata_section  -------------------------*/
/*
  NAME
    add_sdata_section

  DESCRIPTION
    add a new sdata section.

    * tag is unique within a section group

    * at most 99 unique sdata sections with a section group

    * no section name unique within a section group

  ARGUMENTS
    group_name   - section group name, [user.]section_group_name
    section_name - section name
    tag          - the pattern which marks the start of a section
    datatype     - datatype of the section

  NOTES

  EXCEPTIONS

*/
PROCEDURE add_sdata_section(
  group_name     in    varchar2,
  section_name   in    varchar2,
  tag            in    varchar2,
  datatype       in    varchar2  default NULL
);

/*-------------------- add_sdata_column  -------------------------*/
/*
  NAME
    add_sdata_column

  DESCRIPTION
    map the specified FILTER BY or ORDER BY column name to an SDATA
    section

  ARGUMENTS
    group_name   - section group name, [user.]section_group_name
    section_name - SDATA section name
    column_name  - column name.

  NOTES

  EXCEPTIONS

*/
PROCEDURE add_sdata_column(
  group_name     in    varchar2,
  section_name   in    varchar2,
  column_name    in    varchar2
);

/*-------------------- update_sdata  -----------------------------*/
/*
  NAME
    update_sdata

  DESCRIPTION
    update sdata section value

  ARGUMENTS
    idx_name     - index name
    section_name - SDATA section name
    sdata_value  - sdata value
    sdata_rowid  - rowid
    part_name    - partition name

  NOTES

  EXCEPTIONS
*/
PROCEDURE update_sdata(
  idx_name      in varchar2,
  section_name  in varchar2,
  sdata_value   in sys.anydata,
  sdata_rowid   in rowid,
  part_name     in varchar2 default NULL
);

/*-------------------- update_mvdata_set  -----------------------------*/
/*
  NAME
    update_mvdata_set

  DESCRIPTION
    update mvdata section values as a set at document level

  ARGUMENTS
    idx_name     - index name
    section_name - MVDATA section name
    mvdata_value  - mvdata values
    mvdata_rowid  - rowid
    part_name    - partition name

  NOTES

  EXCEPTIONS
*/
PROCEDURE update_mvdata_set(
  idx_name      in varchar2    default NULL,
  section_name  in varchar2    default NULL,
  mvdata_values   in sys.odcinumberlist,
  mvdata_rowid   in rowid,
  part_name     in varchar2    default NULL
);

/*-------------------- insert_mvdata_value  -----------------------------*/
/*
  NAME
    insert_mvdata_value

  DESCRIPTION
    insert mvdata section value

  ARGUMENTS
    idx_name     - index name
    section_name - MVDATA section name
    mvdata_value  - mvdata value
    mvdata_rowid  - rowid
    part_name    - partition name

  NOTES

  EXCEPTIONS
*/
PROCEDURE insert_mvdata_value(
  idx_name      in varchar2    default NULL,
  section_name  in varchar2    default NULL,
  mvdata_value   in number,
  mvdata_rowid   in rowid,
  part_name     in varchar2    default NULL
);

/*-------------------- delete_mvdata_value  -----------------------------*/
/*
  NAME
    delete_mvdata_value

  DESCRIPTION
    delete mvdata section value

  ARGUMENTS
    idx_name     - index name
    section_name - MVDATA section name
    mvdata_value  - mvdata value
    mvdata_rowid  - rowid
    part_name    - partition name

  NOTES

  EXCEPTIONS
*/
PROCEDURE delete_mvdata_value(
  idx_name      in varchar2    default NULL,
  section_name  in varchar2    default NULL,
  mvdata_value   in number,
  mvdata_rowid   in rowid,
  part_name     in varchar2    default NULL
);

/*-------------------- add_mdata_column  -------------------------*/
/*
  NAME
    add_mdata_column

  DESCRIPTION
    map the specified FILTER BY or ORDER BY column name to an MDATA
    section

  ARGUMENTS
    group_name   - section group name, [user.]section_group_name
    section_name - MDATA section name
    column_name  - column name.

  NOTES

  EXCEPTIONS

*/
PROCEDURE add_mdata_column(
  group_name     in    varchar2,
  section_name   in    varchar2,
  column_name    in    varchar2
);

/*-------------------- remove_section ---------------------------*/
/*
  NAME
    remove_section

  DESCRIPTION
    remove section/s from a section group.

    * delete all sections with sec_name in section group 'grp_name'.

    * Only CTXAPP and CTXADMIN can drop a section, moreover, they can
      only drop their own sections.

  ARGUMENTS
    group_name    -  section group name, [user.]section_group_name
    section_name  -  section name , [user.]section_name

  NOTES

  EXCEPTIONS

*/
PROCEDURE remove_section(
  group_name       in    varchar2,
  section_name     in    varchar2
);

/*-------------------- remove_section ---------------------------*/
/*
  NAME
    remove_section

  DESCRIPTION
    remove a section from a section group.

    * Only CTXAPP and CTXADMIN can drop a section, moreover, they can
      only drop their own sections.

  ARGUMENTS
    group_name  -  section group name, [user.]section_group_name
    section_id  -  section id, [user.]section_name

  NOTES

  EXCEPTIONS

*/
PROCEDURE remove_section(
  group_name     in    varchar2,
  section_id     in    number
);


/*-------------------- create_stoplist --------------------------*/
/*
  NAME
    create_stoplist

  DESCRIPTION
    create a new stoplist

  ARGUMENTS
    stoplist_name - name of the stoplist
    stoplist_type - type of stoplist

  NOTES

  EXCEPTIONS

*/
PROCEDURE create_stoplist(
  stoplist_name  in   varchar2,
  stoplist_type  in   varchar2 default 'BASIC_STOPLIST'
);

/*-------------------- drop_stoplist --------------------------*/
/*
  NAME
    drop_stoplist

  DESCRIPTION
    delete a stoplist

  ARGUMENTS
    stoplist_name -  name of the stoplist

  NOTES

  EXCEPTIONS

*/
PROCEDURE drop_stoplist(
  stoplist_name  in   varchar2
);

/*-------------------- add_stopword --------------------------*/
/*
  NAME
    add_stopword

  DESCRIPTION
    add a stopword to a stoplist

  ARGUMENTS
    stoplist_name -  name of the stoplist
    stopword      -  stopword to be added
    language      -  language of the stopword (for MULTI_STOPLIST only)

  NOTES

  EXCEPTIONS

*/
PROCEDURE add_stopword(
  stoplist_name  in   varchar2,
  stopword       in   varchar2,
  language       in   varchar2 default NULL
);

/*-------------------- add_stoptheme --------------------------*/
/*
  NAME
    add_stoptheme

  DESCRIPTION
    add a stoptheme to a stoplist

  ARGUMENTS
    stoplist_name -  name of the stoplist
    stoptheme     -  stoptheme to be added

  NOTES

  EXCEPTIONS

*/
PROCEDURE add_stoptheme(
  stoplist_name  in   varchar2,
  stoptheme      in   varchar2
);

/*-------------------- add_stopclass --------------------------*/
/*
  NAME
    add_stopclass

  DESCRIPTION
    add a stopclass to a stoplist

  ARGUMENTS
    stoplist_name -  name of the stoplist
    stopclass     -  stopclass to be added

  NOTES
    currently only the stopclass NUMBERS is supported

*/
PROCEDURE add_stopclass(
  stoplist_name  in   varchar2,
  stopclass      in   varchar2
);

/*-------------------- remove_stopword --------------------------*/
/*
  NAME
    remove_stopword

  DESCRIPTION
    remove a stopword from a stoplist

  ARGUMENTS
    stoplist_name  -  name of the stoplist
    stopword       -  stopword to be removed
    language       -  language of the stopword (for MULTI_STOPLIST only)

  NOTES

  EXCEPTIONS

*/
PROCEDURE remove_stopword(
  stoplist_name  in   varchar2,
  stopword       in   varchar2,
  language       in   varchar2 default NULL
);

/*-------------------- remove_stoptheme --------------------------*/
/*
  NAME
    remove_stoptheme

  DESCRIPTION
    remove a stoptheme from a stoplist

  ARGUMENTS
    stoplist_name  -  name of the stoplist
    stoptheme       -  stoptheme to be removed

  NOTES

  EXCEPTIONS

*/
PROCEDURE remove_stoptheme(
  stoplist_name  in   varchar2,
  stoptheme       in   varchar2
);

/*-------------------- remove_stopclass --------------------------*/
/*
  NAME
    remove_stopclass

  DESCRIPTION
    remove a stopclass from a stoplist

  ARGUMENTS
    stoplist_name  -  name of the stoplist
    stopclass       -  stopclass to be removed

  NOTES

  EXCEPTIONS

*/
PROCEDURE remove_stopclass(
  stoplist_name  in   varchar2,
  stopclass       in   varchar2
);

/*-------------------- add_sub_lexer ---------------------------*/
/*
  NAME
    add_sub_lexer

  DESCRIPTION
    add a sub lexer to a multi-lexer preference

  ARGUMENTS
    lexer_name     -  name of the multi-lingual lexer preference
    language       -  language of the sub-lexer
    sub_lexer      -  name of the sub-lexer preference for this language
    alt_value      -  alternate value for the language

  NOTES

  EXCEPTIONS

*/
PROCEDURE add_sub_lexer(
  lexer_name     in   varchar2,
  language       in   varchar2,
  sub_lexer      in   varchar2,
  alt_value      in   varchar2 default null
);

/*-------------------- remove_sub_lexer ---------------------------*/
/*
  NAME
    remove_sub_lexer

  DESCRIPTION
    remove a sub lexer from a multi-lexer preference

  ARGUMENTS
    lexer_name     -  name of the multi-lingual lexer preference
    language       -  language of the sub-lexer

  NOTES

  EXCEPTIONS

*/
PROCEDURE remove_sub_lexer(
  lexer_name     in   varchar2,
  language       in   varchar2
);

/*-------------------- sync_index --------------------------*/
/*
  NAME
    sync_index

  DESCRIPTION
    sync index

  ARGUMENTS
    idx_name         - index name
    memory           - index memory
    part_name        - index partition name
    parallel_degree  - parallel degree
    direct_path      - direct path loading

  NOTES

  EXCEPTIONS

*/
PROCEDURE sync_index(
  idx_name        in  varchar2 default NULL,
  memory          in  varchar2 default NULL,
  part_name       in  varchar2 default NULL,
  parallel_degree in  number   default 1,
  maxtime         in  number   default NULL,
  locking         in  number   default LOCK_WAIT,
  direct_path     in boolean   default false
);

/*-------------------- optimize_index --------------------------*/
/*
  NAME
    optimize_index

  DESCRIPTION
    optimize index

  ARGUMENTS
    idx_name  - index name
    optlevel  - optimization level -- FAST or FULL
    maxtime   - max optimization time, in minutes, for FULL optimize
    token     - text token string to optimize, for TOKEN optimize
                note token types 1, 2, 5, 7, and 8 are case-sensitive.
    part_name - index partition name
    token_type - for TOKEN optimize only, the type of the token to optimize
                 (default value: 0).  For name to type resolution, see
                 ctx_report.token_type
    parallel_degree - the degree of parallelism for this optimize.
                 NOTE: parallel optimize is supported ONLY for FULL
                 optimize, on CONTEXT indexes.  Any other conditions
                 will produce an error message.
  NOTES

  EXCEPTIONS

*/
PROCEDURE optimize_index(
  idx_name   in  varchar2,
  optlevel   in  varchar2,
  maxtime    in  number    default null,
  token      in  varchar2  default null,
  part_name  in  varchar2  default null,
  token_type in  number    default null,
  parallel_degree in number default 1
);

/*-------------------- create_index_set  ---------------------------*/
/*
  NAME
    create_index_set

  DESCRIPTION
    create a new index set.

    * index set name is unique within an owner.
    * Only CTXAPP users and CTXSYS can create an index set.

  ARGUMENTS
    set_name  - index set name.  user.name syntax allowed.

  NOTES

  EXCEPTIONS

*/
PROCEDURE create_index_set(
  set_name     in    varchar2
);

/*------------------------------ add_index ---------------------------------*/
/*
  NAME
    add_index

  DESCRIPTION
    add a new index to an index set.

    * column list is unique within an index set

    * at most 100 indexes in an index set

  ARGUMENTS
    set_name       - index set name
    column_list    - column list for the index
    storage_clause - index storage clause

  NOTES

  EXCEPTIONS

*/
PROCEDURE add_index(
  set_name       in    varchar2,
  column_list    in    varchar2,
  storage_clause in    varchar2 default null
);

/*-------------------- remove_index ---------------------------*/
/*
  NAME
    remove_index

  DESCRIPTION
    remove index with the specified column list from an index set.

  ARGUMENTS
    set_name      -  index set name
    column_list   -  index column list

  NOTES

  EXCEPTIONS

*/
PROCEDURE remove_index(
  set_name       in    varchar2,
  column_list    in    varchar2
);

/*-------------------- drop_index_set  ---------------------------*/
/*
  NAME
    drop_index_set

  DESCRIPTION
    drop an index set.

  ARGUMENTS
    set_name  -  index set name

  NOTES

  EXCEPTIONS

*/
PROCEDURE drop_index_set(
  set_name     in    varchar2
);

/*-------------------- create_policy  ---------------------------*/
/*
  NAME
    create_policy

  DESCRIPTION
    create a policy.

  ARGUMENTS
    policy_name   - the name for the new policy
    filter        - the filter preference to use
    section_group - the section group to use
    lexer         - the lexer preference to use
    stoplist      - the stoplist preference to use
    wordlist      - the wordlist preference to use

  NOTES

  EXCEPTIONS

*/
PROCEDURE create_policy(
  policy_name   in varchar2,
  filter        in varchar2 default NULL,
  section_group in varchar2 default NULL,
  lexer         in varchar2 default NULL,
  stoplist      in varchar2 default NULL,
  wordlist      in varchar2 default NULL
);

/*-------------------- update_policy  ---------------------------*/
/*
  NAME
    update_policy

  DESCRIPTION
    update a policy.  Replaces the preferences of the policy.
    arguments left null will not be replaced.

  ARGUMENTS
    policy_name   - the name for the policy
    filter        - the new filter preference to use
    section_group - the new section group to use
    lexer         - the new lexer preference to use
    stoplist      - the new stoplist preference to use
    wordlist      - the new wordlist preference to use

  NOTES

  EXCEPTIONS

*/
PROCEDURE update_policy(
  policy_name   in varchar2,
  filter        in varchar2 default NULL,
  section_group in varchar2 default NULL,
  lexer         in varchar2 default NULL,
  stoplist      in varchar2 default NULL,
  wordlist      in varchar2 default NULL
);

/*-------------------- copy_policy  ---------------------------*/
/*
  NAME
    copy_policy

  DESCRIPTION
    create a policy which is a metadata copy of an existing policy
    or index.

  ARGUMENTS
    source_policy  - the source policy
    policy_name    - the new policy

  NOTES
    currently the owner of the old and new policies must be the same
*/
PROCEDURE copy_policy(
  source_policy  in varchar2,
  policy_name    in varchar2
);

/*-------------------- drop_policy  ---------------------------*/
/*
  NAME
    drop_policy

  DESCRIPTION
    drop a policy.

  ARGUMENTS
    policy_name   - the name of the policy

  NOTES

  EXCEPTIONS

*/
PROCEDURE drop_policy(
  policy_name   in varchar2
);

/*-------------------- add_mdata  ---------------------------*/
/*
  NAME
    add_mdata

  DESCRIPTION
    add mdata values to existing documents
*/
PROCEDURE add_mdata(
  idx_name      in varchar2,
  section_name  in varchar2,
  mdata_value   in varchar2,
  mdata_rowid   in rowid,
  part_name     in varchar2  default null
);
PROCEDURE add_mdata(
  idx_name      in varchar2,
  section_name  in varchar2,
  mdata_values  in sys.odcivarchar2list,
  mdata_rowids  in sys.odciridlist,
  part_name     in varchar2  default null
);

/*-------------------- remove_mdata  ---------------------------*/
/*
  NAME
    remove_mdata

  DESCRIPTION
    remove mdata values from existing documents
*/
PROCEDURE remove_mdata(
  idx_name      in varchar2,
  section_name  in varchar2,
  mdata_value   in varchar2,
  mdata_rowid   in rowid,
  part_name     in varchar2  default null
);
PROCEDURE remove_mdata(
  idx_name      in varchar2,
  section_name  in varchar2,
  mdata_values  in sys.odcivarchar2list,
  mdata_rowids  in sys.odciridlist,
  part_name     in varchar2  default null
);

PROCEDURE replace_index_metadata(
  idx_name         in varchar2,
  parameter_string in varchar2
);

/*-------------------- populate_pending  ---------------------------*/
/*
  NAME
    populate_pending

  DESCRIPTION
    loads the DML pending queue with all base table rowids
    intended to be used after a create index ... NOPOPULATE
*/
PROCEDURE populate_pending(
  idx_name      in varchar2,
  part_name     in varchar2  default null
);

PROCEDURE recreate_index_online(
  idx_name         in varchar2,
  parameter_string in varchar2 default null,
  parallel_degree  in number default 1,
  partition_name   in varchar2 default null
);

PROCEDURE create_shadow_index(
  idx_name      in varchar2,
  parameter_string in varchar2 default null,
  parallel_degree  in number default 1
);

PROCEDURE exchange_shadow_index(
  idx_name       in varchar2,
  partition_name in varchar2 default null
);

procedure drop_shadow_index(
  idx_name   varchar2
);

/*-------------------- split_zone_tokens ---------------------------*/
/*
  NAME
    split_zone_tokens

  DESCRIPTION
    To move contents of a zone section to one or more zone sections
*/

PROCEDURE split_zone_tokens(
  idx_name        in varchar2,
  part_name       in varchar2 default null,
  source_section  in varchar2,
  split_map       in split_tab
);

END ctx_ddl;
/

