create package drvxmd authid current_user is


/*---------------------------- GetIndexMD  -------------------------------*/
/* fetch selected dr$index column values into out variables */

procedure GetIndexMD(
  p_idxid           in  number,
  o_owner           out varchar2,
  o_owner#          out number,
  o_name            out varchar2,
  o_table_obj#      out number,
  o_table_dataobj#  out number,
  o_key_name        out varchar2,
  o_key_type        out binary_integer,
  o_text_name       out varchar2,
  o_text_type       out binary_integer,
  o_text_length     out binary_integer,
  o_lang_col        out varchar2,
  o_fmt_col         out varchar2,
  o_cset_col        out varchar2,
  o_idx_type        out binary_integer,
  o_idx_option      out varchar2,
  o_idx_sync_type   out varchar2,
  o_idx_sync_memory out binary_integer,
  o_idx_src_name    out varchar2,
  o_idx_src_id      out binary_integer,
  o_idx_version     out binary_integer
);

/*---------------------------- GetIndexPartition  -----------------------*/
/* get dr$index_partition information */

procedure GetIndexPartition(
  o_id               out number,
  o_tabpart_dataobj# out number,
  o_sync_type        out varchar2,
  o_sync_memory      out number,
  o_option           out varchar2,
  i_cid               in number,
  i_pname             in varchar2
);

/*---------------------------- OpenIndexMDScan ----------------------*/
/* open dr$index_object and value cursors */

procedure OpenIndexMDScan(
  p_idxid           in  number
);

/*---------------------------- NextIndexObject ---------------------------*/
/* get next dr$index_object cursor */

function NextIndexObject(
  o_cla_id          out binary_integer,
  o_obj_id          out binary_integer,
  o_acnt            out binary_integer
) return binary_integer;

/*---------------------------- NextIndexValue ----------------------------*/
/* get next dr$index_value cursor */

function NextIndexValue(
  o_cla_id          out binary_integer,
  o_att_id          out binary_integer,
  o_datatype        out binary_integer,
  o_sub_group       out binary_integer,
  o_sub_att_id      out binary_integer,
  o_sub_datatype    out binary_integer,
  o_value           out varchar2
) return binary_integer;

/*---------------------------- NextIndexCDI ---------------------------*/
/* get next dr$index_cdi_column cursor */

function NextIndexCDI(
  o_cdi_pos         out binary_integer,
  o_cdi_type#       out binary_integer,
  o_cdi_len         out binary_integer,
  o_cdi_name        out varchar2,
  o_cdi_sec         out varchar2,
  o_cdi_stype       out binary_integer,
  o_cdi_id          out binary_integer
) return binary_integer;

/*---------------------------- GetDocidCount -----------------------------*/
/* get docid count */

function GetDocidCount(
  p_idxid           in number,
  p_ixpid           in number default null
) return number;

/*---------------------------- GetIndexStats -----------------------------*/
/* get index stats from dr$stats */

procedure GetIndexStats(
  p_idxid           in number,
  p_smplsz          in out nocopy number
);

/*---------------------------- GetBaseTableName --------------------------*/
/* get base table name */

function GetBaseTableName(
  p_idxid           in number,
  p_ixpid           in number default null
) return varchar2;

/*---------------------------- IncrementDocCnt --------------------------*/
/* increment docid count */

procedure IncrementDocCnt(
  p_idxid           in number,
  p_ixpid           in number,
  p_delta           in number
);

/*---------------------------- AllocateDocids ---------------------------*/
/* allocate docids */

procedure AllocateDocids(
  p_idxid           in  number,
  p_ixpid           in  number,
  p_allocsz         in  binary_integer,
  p_startid         out number
);

/*--------------------------- IncrementVersion -------------------------*/
/* increment version of index */
procedure IncrementVersion(
  p_idxid in number
);

/*---------------------------- RecordIndexError -------------------------*/
/* records an error to the dr$index_error table */

procedure RecordIndexError(
  p_idxid           in number,
  p_textkey         in varchar2,
  p_stack           in varchar2
);

/*---------------------------- OptStartTimer -----------------------------*/
/* starts optimization timer */

procedure OptStartTimer;

/*---------------------------- OptGetTimer -------------------------------*/
/* gets optimization timer */

function OptGetTimer return binary_integer;

/*---------------------------- OptGetState -------------------------------*/
/* get full optimize state */

procedure OptGetState(
  p_idxid       in  number,
  p_ixpid       in  number,
  p_ntable_name in  varchar2,
  p_itable_name in  varchar2,
  p_beg_s_opt   in  boolean,
  o_opt_token   out varchar2,
  o_opt_type    out number,
  o_opt_count   out number
);

/*---------------------------- OptGetType -------------------------------*/
/* get type optimize start token */

procedure OptGetType(
  p_idxid       in  number,
  p_ixpid       in  number,
  p_ntable_name in  varchar2,
  p_itable_name in  varchar2,
  o_opt_token   out varchar2,
  o_opt_type    in  number,
  o_opt_count   out number
);

/*---------------------------- OptSetState -------------------------------*/
/* set full optimize state */

procedure OptSetState(
  p_idxid       in  number,
  p_ixpid       in  number,
  p_ntable_name in  varchar2,
  p_opt_token   in  varchar2,
  p_opt_type    in  number
);

/*---------------------------- GetFieldSecName -----------------------------*/
/* get field section name */

function GetFieldSecName (
  p_idxid  in number,
  p_secid  in number
) return varchar2;

/*---------------------------- GetPrefClaObj -----------------------------*/

procedure GetPrefClaObj(
  p_preid  in  number,
  o_claid  out number,
  o_objid  out number
);

/*---------------------------- GetObjDefault -----------------------------*/

procedure GetObjDefault(
  p_oatid   in  number,
  o_default out varchar2
);

/*---------------------------- OpenPrefValue ------------------------------*/

procedure OpenPrefValue(
  p_preid   in number
);

/*---------------------------- NextPrefValue ------------------------------*/

function NextPrefValue(
  o_value   out varchar2,
  o_oatid   out number
) return binary_integer;

/*---------------- set_reverse_docid_switch  -------------------*/
/*
  NAME
    Set_reverse_docid_switch

  DESCRIPTION
    Turns ON/OFF reverse docid processing for a specified index.

  ARGUMENTS
    owner_name     index owner
    index_name     index name
    value          switch value (ON or OFF)
*/
PROCEDURE set_reverse_docid_switch(
  owner_name     in  varchar2,
  index_name     in  varchar2,
  value          in  varchar2
);

/*--------------- GetMVFlag ------------------------------------------------*/
/*
  NAME
    GetMVFlag

  DESCRIPTION
    Check whether it's index on Materialized View

  ARGUMENTs
    table_id
    owner_name
    opt              1 -- index on MView
                     0 -- not index on MView
*/

PROCEDURE GetMVFlag(
  table_id       in  number,
  owner_name     in  varchar2,
  opt            out binary_integer
);

/*---------------------------- GetSecDataType -----------------------------*/
/* get section datatype, mainly for MDATA and SDATA */

function GetSecDataType (
  p_idxid  in number,
  p_secid  in number
) return number;

/*---------------------------- ChkIndexOption -----------------------------*/
/*
  Take in index id, and an option letter (see drdmlop() for a list of
  options), return 1 if the given option is set, 0 otherwise.
*/
function ChkIndexOption (
  p_idxid  in number,
  p_opt    in varchar2
) return number;

/*--------------------------- ctx_sqe_tbl_func ------------------------------*/
/*
  Table function for creating the ctx_user_sqes view
*/
type ctx_sqe_type is record(
  sqe_owner# number,
  sqe_name varchar2(30),
  sqe_query clob);

type ctx_sqe_type_tab is table of ctx_sqe_type;

function ctx_sqe_tbl_func
  return ctx_sqe_type_tab pipelined;

/*---------------------- check_file_access_role -----------------------------*/
/*
   Returns TRUE if the specified user has the role given by file_access_role
   and can therefore create/sync indexes using file or URL datastore
*/
function check_file_access_role(p_user IN varchar2) return boolean;

end drvxmd;
/

