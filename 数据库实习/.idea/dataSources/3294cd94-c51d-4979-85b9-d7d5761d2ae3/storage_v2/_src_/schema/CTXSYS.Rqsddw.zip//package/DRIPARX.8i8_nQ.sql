create package driparx as

  procedure set_session_state(sess_state dr$session_state_t);
  function  get_session_state return dr$session_state_t;
  procedure end_parallel_op(sess_state dr$session_state_t);

  procedure  setContext(mykey  in varchar2, myval in sys.anydata);
  procedure  clearContext(mykey in varchar2);
  function   getContext(mykey in varchar2) return sys.anydata;

end driparx;
/

