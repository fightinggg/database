create package drimlx as

/*-------------------- add_sub_lexer ---------------------------*/

PROCEDURE add_sub_lexer(
  lexer_name     in   varchar2,
  language       in   varchar2,
  sub_lexer      in   varchar2,
  alt_value      in   varchar2 default NULL
);

/*-------------------- remove_sub_lexer ---------------------------*/

PROCEDURE remove_sub_lexer(
  lexer_name     in   varchar2,
  language       in   varchar2
);

/*----------------------- copy_multi_lexer -------------------------------*/
procedure copy_multi_lexer(
  p_idx_id in  number,
  p_pref   in  dr_def.pref_rec,
  p_rcount out number
);

/*----------------------- GetIndexMultiLexer -----------------------------*/
procedure GetIndexMultiLexer(
  p_idx_id in  number,
  o_slx in out nocopy dr_def.slx_tab
);

end drimlx;
/

