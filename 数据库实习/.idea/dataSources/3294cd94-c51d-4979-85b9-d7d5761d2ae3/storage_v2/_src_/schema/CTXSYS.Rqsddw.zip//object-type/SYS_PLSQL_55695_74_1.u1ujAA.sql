create type          SYS_PLSQL_55695_74_1 as object (DOCID NUMBER,
CATID NUMBER,
SCR NUMBER);
/

