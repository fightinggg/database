create package driixs as

/*-------------------- create_index_set  ---------------------------*/

PROCEDURE create_index_set(
  set_name     in    varchar2
);

/*------------------------------ add_index -------------------------*/

PROCEDURE add_index(
  set_name       in    varchar2,
  column_list    in    varchar2,
  storage_clause in    varchar2 default null
);

/*-------------------- remove_index ---------------------------*/

PROCEDURE remove_index(
  set_name       in    varchar2,
  column_list    in    varchar2
);

/*-------------------- drop_index_set  ---------------------------*/

PROCEDURE drop_index_set(
  set_name     in    varchar2
);

/*---------------------- drop_user_index_sets ----------------------*/
PROCEDURE drop_user_index_sets(
  user_name in varchar2 := null
);

/*------------------------ copy_index_set ------------------------------*/

function copy_index_set(
  p_idx_id     in  number,
  p_indexset   in  varchar2,
  p_rcount     out number
)
return dr_def.pref_rec;

/*----------------------- GetIndexIndexSet --- -------------------------*/
/* get index set from already-existing index */

PROCEDURE GetIndexIndexSet(
  p_idx_id    in  number,
  o_ixx       in out nocopy dr_def.ixx_tab
);

/*----------------------- GetIndexIXSColumns -----------------------------*/
/* get index set columns from already-existing index */

PROCEDURE GetIndexIXSColumns(
  p_idx_id    in  number,
  o_cols      in out nocopy dr_def.ixc_tab
);

end driixs;
/

