create type          SYS_PLSQL_55695_DUMMY_1 as table of number;
/

