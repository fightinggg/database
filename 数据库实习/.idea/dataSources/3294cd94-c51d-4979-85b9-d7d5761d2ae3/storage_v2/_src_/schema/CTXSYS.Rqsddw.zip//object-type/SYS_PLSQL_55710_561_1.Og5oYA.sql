create type          SYS_PLSQL_55710_561_1 as table of CTXSYS."SYS_PLSQL_55710_541_1";
/

