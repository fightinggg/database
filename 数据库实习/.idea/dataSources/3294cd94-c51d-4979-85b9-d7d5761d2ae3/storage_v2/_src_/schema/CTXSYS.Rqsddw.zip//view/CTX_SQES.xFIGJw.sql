create view CTX_SQES as
select u.name     sqe_owner,
       sqe_name,
       sqe_query
  from dr$sqe sqe, sys.user$ u
 where sqe_owner# = u.user#
/

